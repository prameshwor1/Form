let forms = [];

    const addForm = (ev)=>{
        ev.preventDefault();

        let form = {
            Fullname: document.getElementById('name').value,
            Username: document.getElementById('urname').value,
            Email: document.getElementById('email').value,
            Number: document.getElementById('num').value,
            Password: document.getElementById('psd').value,
            Confirmpassword: document.getElementById('pasd').value,
            Gender: document.querySelector('input[name="gender"]:checked').value,
            Profession: document.querySelector('input[name="profession"]:checked').value
        }
        forms.push(form);
        document.forms[0].reset();

        //<---for the display purpose only ---->
        console.warn('addded' , {forms} );
        let pre = document.querySelector('#msg pre');
        pre.textContent = '\n' + JSON.stringify(forms, '\t', 2);

        

        //saving to local storage
    localStorage.setItem('Datalist', JSON.stringify(forms));
    }
    

    document.addEventListener('DOMContentLoaded', ()=>{
        document.getElementById('btn').addEventListener('click', addForm);
}); 