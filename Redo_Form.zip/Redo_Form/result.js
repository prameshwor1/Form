const message = document.querySelector('#msg');

 const params = new URLSearchParams(window.location.search);

params.forEach((value, key) =>{
    message.append(`${key} = ${value}`);
    message.append(document.createElement('br'));
});


