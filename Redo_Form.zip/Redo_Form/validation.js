

const form = document.getElementById('form');
const fname = document.getElementById('fname');
const email = document.getElementById('email');
const number = document.getElementById('number');
const password = document.getElementById('password');
const cpassword = document.getElementById('cpassword');
// const gender = document.querySelector('input[name="gender"]:checked').value;
//const gender = document.querySelector('input[name="gender"]:checked').value

form.addEventListener('submit', (e) => {
   
   validate();
   //display();
   //0 or 1 of form submit
   if(isFormValid()== true){
      form.submit();
   } else {
      
      e.preventDefault();
   }
});
//to stop invalid submission
function isFormValid(){
   const inputContainers = form.querySelectorAll('.input-box');
   let result = true;
   inputContainers.forEach((container)=>{
      if(container.classList.contains('error')){
         result = false;
      }
   });

   return result;
}

function validate(){
   const fnameVal = fname.value.trim();
   const emailVal = email.value.trim();
   const numberVal = number.value.trim();
   const passwordVal = password.value.trim();
   const cpasswordVal = cpassword.value.trim();
  
//for fullname
   if(fnameVal === ""){
      setErrorFor(fname, 'Fullname cannot be blank');
   } else if(fnameVal.length <3 || fnameVal.length >15 ){
       setErrorFor(fname, 'Fullname min 3 and max 15 char'); 
   } else{
       setSuccessFor(fname);
   }
//for email
   if(emailVal === ""){
      setErrorFor(email, 'email cannot be blank');
    } else{
       setSuccessFor(email);
    }
   
// for phone number
   if(numberVal === ""){
   setErrorFor(number, 'number cannot be blank');
   } else if(numberVal.length != 10){
   setErrorFor(number, 'number is not valid');
   }
    else{
    setSuccessFor(number);
   }
//for password
if(passwordVal === ''){
setErrorFor(password, 'password cannot be blank');
} else if(passwordVal.length <= 5 || passwordVal.length >= 15   ){
setErrorFor(password, 'min char 6 max char 15');
}
else{
   setSuccessFor(password);
}
//for confirming password
if(cpasswordVal === ''){
   setErrorFor(cpassword, 'password cannot be blank');
   } else if(passwordVal !== cpasswordVal){
      setErrorFor(cpassword, 'password didnot match');
   }else {
      setSuccessFor(cpassword);
   }

 
}
   //function to display error!
function setErrorFor(input, message) {
   const inputBox = input.parentElement; //.input-box class
   const small = inputBox.querySelector('small');
   //add error message inside small element
   small.innerText = message;
//add error class
   inputBox.className = 'input-box error';
}

function setSuccessFor(input) {
   const inputBox = input.parentElement;
   inputBox.className = 'input-box success';
}

// function isEmail(email) {
//  const reg = /^[a-zA-Z0-9.! #$%&'*+/=? ^_`{|}~-]+@[a-zA-Z0-9-]+(?:\. [a-zA-Z0-9-]+)*$/
// return reg.test(email); 
// }



   



